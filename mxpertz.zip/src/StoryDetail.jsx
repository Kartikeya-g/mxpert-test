import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';

const StoryDetail = () => {
    const { id } = useParams();
    const [story, setStory] = useState(null);

    useEffect(() => {
        fetch(`https://child.onrender.com/api/sciencefiction/${id}`)
            .then(response => response.json())
            .then(data => setStory(data));
    }, [id]);

    if (!story) {
        return <div>Loading...</div>;
    }

    return (
        <div className="story-detail">
            <h2>{story.Title}</h2>
            <p>Author: {story.author}</p>
            <p>{story.content}</p>
        </div>
    );
};

export default StoryDetail;
