import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import './Stories.css';

const Stories = () => {
    const [stories, setStories] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [selectedStatus, setSelectedStatus] = useState('all'); // Add state for selected status
    const storiesPerPage = 8;

    useEffect(() => {
        fetch('https://child.onrender.com/api/sciencefiction')
            .then(response => response.json())
            .then(data => setStories(data));
    }, []);

    const indexOfLastStory = currentPage * storiesPerPage;
    const indexOfFirstStory = indexOfLastStory - storiesPerPage;
    const currentStories = stories.slice(indexOfFirstStory, indexOfLastStory);

    const handleNextPage = () => {
        if (currentPage < Math.ceil(stories.length / storiesPerPage)) {
            setCurrentPage(prevPage => prevPage + 1);
        }
    };

    const handlePreviousPage = () => {
        if (currentPage > 1) {
            setCurrentPage(prevPage => prevPage - 1);
        }
    };

    // Function to handle status button click
    const handleStatusClick = (status) => {
        setSelectedStatus(status);
    };

    // Filter stories based on selected status
    const filteredStories = selectedStatus === 'all' ? stories : stories.filter(story => story.Status === selectedStatus);

    return (
        <div className="stories-container">
            <header>
                <div className="logo">BrainyLingo</div>
                <nav>
                    <ul>
                        <li><a href="#">Home</a></li>
                        <li><a href="#">Leaderboard</a></li>
                        <li><a href="#">Daily Quiz</a></li>
                        <li><a href="#">Genres</a></li>
                    </ul>
                </nav>
                <button className="sign-out">Sign Out</button>
            </header>

            <div className='sub-heading'>
                <h1>Science Fiction Stories</h1>
                <div className="status-buttons">
                    {/* Add onClick event handlers to status buttons */}
                    <button className="status-btn" onClick={() => handleStatusClick('all')}>All</button>
                    <button className="status-btn" onClick={() => handleStatusClick('New')}>New</button>
                    <button className="status-btn" onClick={() => handleStatusClick('In Progress')}>In Progress</button>
                    <button className="status-btn" onClick={() => handleStatusClick('Completed')}>Completed</button>
                </div>
            </div>

            <div className="stories-container-sub">
                {/* Render filtered stories */}
                {filteredStories.map(story => (
                    <div key={story.id} className="card">
                        <img src={`https://ik.imagekit.io/dev24/${story.Image}`} alt={story.Title} />
                        <h3>{story.Title}</h3>
                        <Link to={`/story/${story.id}`}>
                            {story.Status}
                        </Link>
                    </div>
                ))}

                <div className="pagination-buttons">
                    <button onClick={handlePreviousPage} disabled={currentPage === 1}>
                        Previous
                    </button>
                    <button onClick={handleNextPage} disabled={currentPage >= Math.ceil(stories.length / storiesPerPage)}>
                        Next
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Stories;
